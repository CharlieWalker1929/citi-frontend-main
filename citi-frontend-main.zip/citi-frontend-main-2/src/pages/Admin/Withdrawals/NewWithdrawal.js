import PropTypes from "prop-types"
import { useHistory } from "react-router-dom"
import React, { useEffect, useState } from "react"
import MetaTags from "react-meta-tags"
import {
  Container,
  Row,
  Col,
  Button,
  Card,
  CardBody,
  Input,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Media,
  Table,
  Label,
} from "reactstrap"
import { Link } from "react-router-dom"
import {
  AvForm,
  AvField,
  AvGroup,
  AvInput,
} from "availity-reactstrap-validation"

// Pages Components
import TransactionTable from "./TransactionTable"

import { get, post } from "helpers/api_helper"

//Import Breadcrumb
import Breadcrumbs from "components/Common/Breadcrumb"

const NewWithdrawal = props => {
  const history = useHistory()
  const [loading, setLoading] = useState(true)
  const [clients, setClients] = useState([])
  const [withdrawal, setWithdrawal] = useState(null)
  const [approveWithdrawalLoading, setApproveWithdrawalLoading] =
    useState(false)

  const editWithdrawalId = props.match.params.id ? props.match.params.id : null
  console.log(editWithdrawalId)

  const handleValidSubmit = (event, value) => {
    if (withdrawal !== null) {
      var updatedWithdrawal = {
        ...value,
        id: editWithdrawalId,
        amount: -value.amount,
      }

      post("/deposits/update", updatedWithdrawal).then(response => {
        history.push("/admin-withdrawals")
      })
      return
    }

    event.preventDefault()
    console.log(value)
    value.amount = -value.amount
    post("/deposits/create", value).then(res => {
      console.log(res)
      history.push("/admin-withdrawals")
    })
  }

  const handleDelete = () => {
    console.log("Delete withdrawal...")
    console.log("Routing to homepage.")
    post("/deposits/delete", { id: withdrawal.id }).then(res => {
      console.log(res)
      history.push("/admin-withdrawals")
    })
  }

  const approveWithdrawal = () => {
    setApproveWithdrawalLoading(true)

    const update = {
      status: "Successful",
      id: withdrawal.id,
      client: withdrawal.client,
    }

    console.log(withdrawal.id)

    post("/deposits/approve", update).then(response => {
      setApproveWithdrawalLoading(false)
      history.push("/admin-withdrawals")
    })
  }

  useEffect(async () => {
    get("users/allClients").then(clients => setClients(clients))
  }, [])

  // Fetch withdrawal if relevant
  useEffect(async () => {
    if (editWithdrawalId !== null) {
      get(`/deposits/${editWithdrawalId}/deposit`).then(withdrawal => {
        setWithdrawal(withdrawal[0])
        console.log(withdrawal[0])
      })
    }
  }, [])

  let clientsValue = clients.length > 0 ? clients[0].email : ""

  if (editWithdrawalId && withdrawal) clientsValue = withdrawal.client

  return (
    <React.Fragment>
      <div className="page-content">
        <MetaTags>
          <title>Citi Group (Australia) Ltd | Admin Withdrawals</title>
        </MetaTags>
        <Container fluid>
          {/* Render Breadcrumb */}
          <Breadcrumbs title={"Admin"} breadcrumbItem={"Add New Withdrawal"} />

          <Card>
            <CardBody>
              <AvForm
                className="form-horizontal"
                onValidSubmit={(e, v) => {
                  handleValidSubmit(e, v)
                }}
              >
                <div className="form-group">
                  <Row>
                    <Col lg={6}>
                      <div className="mb-3">
                        <AvField
                          type="select"
                          name="client"
                          value={clientsValue}
                          label="Client"
                          required
                        >
                          {clients.map(client => {
                            return <option>{client.email}</option>
                          })}
                        </AvField>
                      </div>
                    </Col>
                    <Col lg={6}>
                      <div className="mb-3">
                        <AvField
                          type="select"
                          name="currency"
                          label="Currency"
                          value={withdrawal && withdrawal.currency}
                          required
                        >
                          <option>AUD</option>
                          <option>EUR</option>
                          <option>USD</option>
                          <option>AUD</option>
                          <option>YEN</option>
                          <option>BTC</option>
                          <option>USDT</option>
                        </AvField>
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={6}>
                      <div className="mb-3">
                        <AvField
                          type="text"
                          label="Amount"
                          className="form-control"
                          name="amount"
                          id="amount"
                          value={withdrawal && -withdrawal.amount}
                          required
                        />
                      </div>
                    </Col>

                    <Col lg={6}>
                      <div className="mb-3">
                        <AvGroup>
                          <Label for="dateCreated">Date</Label>
                          <AvInput
                            name="dateCreated"
                            id="dateCreated"
                            type="date"
                            value={withdrawal && withdrawal.dateCreated}
                          />
                        </AvGroup>
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    <Col lg={6}>
                      <div className="mb-3">
                        <AvField
                          type="select"
                          name="status"
                          label="Status"
                          required
                          id="Someting else"
                          value={withdrawal ? withdrawal.status : "Successful"}
                        >
                          <option>Successful</option>
                          <option>Pending</option>
                        </AvField>
                      </div>
                    </Col>
                  </Row>
                </div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    marginTop: "10px",
                  }}
                >
                  <div>
                    {withdrawal && withdrawal.status == "Pending" && (
                      <Button
                        style={{
                          marginRight: "20px",
                          background: "black",
                          color: "white",
                          border: "none",
                        }}
                        onClick={approveWithdrawal}
                        disabled={approveWithdrawalLoading}
                        // PUT UPDATE WITHDRAWAL HERE
                      >
                        Approve Withdrawal
                        {approveWithdrawalLoading && (
                          <i className="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>
                        )}
                      </Button>
                    )}
                  </div>
                  <div>
                    <Button
                      type="submit"
                      style={{
                        marginRight: "20px",
                        background: "black",
                        color: "white",
                        border: "none",
                      }}
                    >
                      {withdrawal ? "Update withdrawal" : "Save withdrawal"}
                    </Button>
                    {withdrawal && (
                      <Button
                        onClick={() => handleDelete()}
                        color="danger"
                        style={{ marginLeft: "20px" }}
                      >
                        Delete
                      </Button>
                    )}
                  </div>
                </div>
              </AvForm>
            </CardBody>
          </Card>
        </Container>
      </div>
    </React.Fragment>
  )
}

NewWithdrawal.propTypes = {}

export default NewWithdrawal
